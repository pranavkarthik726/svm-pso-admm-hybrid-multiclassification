import numpy as np
from cvxopt import matrix, solvers

def ADMM_train(X, y, C, kernel, max_iter=1000, rho=1.0, tol=1e-4):
    """
    SVM training using QP solver (cvxopt)
    """
    n_samples = X.shape[0]
    
    # Ensure y contains only -1 and 1
    assert np.all(np.abs(y) == 1), "Labels must be either -1 or 1"
    
    # Convert y to double precision
    y = y.astype(np.float64)
    
    # Compute kernel matrix
    K = kernel(X, X)
    
    # Formulate the quadratic programming problem
    # Standard form: minimize (1/2)x^T P x + q^T x
    # subject to: Gx <= h
    #            Ax = b
    P = matrix(K)
    q = matrix(-np.ones(n_samples))
    G = matrix(np.vstack((-np.eye(n_samples),  # alpha_i >= 0
                          np.eye(n_samples))))  # alpha_i <= C
    h = matrix(np.hstack((np.zeros(n_samples), 
                         C * np.ones(n_samples))))
    A = matrix(y.reshape(1, -1))
    b = matrix(0.0)
    
    # Solve QP problem
    solvers.options['show_progress'] = False
    solution = solvers.qp(P, q, G, h, A, b)
    
    # Extract results
    alpha = np.array(solution['x']).flatten()
    
    # Compute bias term b
    sv_idx = (alpha > 1e-6) & (alpha < C - 1e-6)
    if np.sum(sv_idx) > 0:
        b = np.mean(y[sv_idx] - np.sum(K[sv_idx][:, sv_idx] * (alpha[sv_idx] * y[sv_idx]), axis=1))
    else:
        b = 0.0
        
    return alpha, b
