import numpy as np
from cvxopt import matrix, solvers

def ADMM_train(X:np.array, y:np.array, C:float, kernel, max_iter:int=1000, rho:float=1.0, tol:float=1e-4):
    n_samples = X.shape[0]
    
    # Ensure y contains only -1 and 1
    assert np.all(np.abs(y) == 1), "Labels must be either -1 or 1"
    
    # Convert arrays to double precision and ensure contiguous memory layout
    X = np.ascontiguousarray(X, dtype=np.float64)
    y = np.ascontiguousarray(y, dtype=np.float64)
    
    # Compute kernel matrix and ensure it's double precision
    K = np.ascontiguousarray(kernel(X, X), dtype=np.float64)
    
    # Convert to CVXOPT matrices with explicit double precision
    P = matrix(K, tc='d')
    q = matrix(-np.ones(n_samples, dtype=np.float64), tc='d')
    G = matrix(np.vstack((-np.eye(n_samples), 
                          np.eye(n_samples))), tc='d')
    h = matrix(np.hstack((np.zeros(n_samples), 
                         C * np.ones(n_samples))), tc='d')
    A = matrix(y.reshape(1, -1), tc='d')
    b = matrix(np.array([0.0], dtype=np.float64), tc='d')
    
    # Rest of the function remains the same...
    
    # Solve QP problem
    solvers.options['show_progress'] = False
    solution = solvers.qp(P, q, G, h, A, b)
    
    # Extract results
    alpha = np.array(solution['x']).flatten()
    
    # Compute bias term b
    sv_idx = (alpha > 1e-6) & (alpha < C - 1e-6)
    if np.sum(sv_idx) > 0:
        b = np.mean(y[sv_idx] - np.sum(K[sv_idx][:, sv_idx] * (alpha[sv_idx] * y[sv_idx]), axis=1))
    else:
        b = 0.0
        
    return alpha, b
