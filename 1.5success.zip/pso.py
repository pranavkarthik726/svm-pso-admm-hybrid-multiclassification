import numpy as np
from ADMM import *
from RBFkernel import gaussian_kernel, sigmoid_kernel

def run_admm_and_get_accuracy(X_train, y_train, X_test, y_test, C, sigma, rho, kernel_type='rbf', kernel_params=None, admm_max_iter=10):
    """Helper function to run ADMM and calculate accuracy on test set"""
    if kernel_type == 'rbf':
        kernel = lambda X1, X2: gaussian_kernel(X1, X2, sigma)
    elif kernel_type == 'sigmoid':
        gamma = kernel_params.get('gamma', 1.0)
        coef0 = kernel_params.get('coef0', 0.0)
        kernel = lambda X1, X2: sigmoid_kernel(X1, X2, gamma, coef0)
    
    try:
        # Train on training data
        alpha, b = ADMM_train(X_train, y_train, C, kernel, max_iter=admm_max_iter)
        
        # Calculate predictions on test data
        K = kernel(X_train, X_test)
        predictions = np.sign((alpha * y_train).dot(K) + b)
        accuracy = np.mean(predictions == y_test)
        return accuracy
    except Exception as e:
        print(f"Error in ADMM training: {e}")
        return -np.inf

def PSO_train(X, y, max_iter=100, n_particles=10, w=0.7, c1=1.5, c2=1.5, admm_max_iter=1000, val_split=0.2):
    """
    PSO algorithm to optimize parameters using validation accuracy
    
    Additional Parameters:
    -----------
    val_split : float
        Fraction of data to use for validation (default: 0.2)
    """
    # Split data into training and validation sets
    n_samples = len(X)
    indices = np.random.permutation(n_samples)
    n_val = int(n_samples * val_split)
    val_idx = indices[:n_val]
    train_idx = indices[n_val:]
    
    X_train, X_val = X[train_idx], X[val_idx]
    y_train, y_val = y[train_idx], y[val_idx]
    
    print(f"PSO_train called with max_iter={max_iter}, n_particles={n_particles}, w={w}, c1={c1}, c2={c2}, admm_max_iter={admm_max_iter}")
    """
    PSO algorithm to optimize rho, sigma, and C parameters for SVM
    
    Parameters:
    -----------
    X : array-like of shape (n_samples, n_features)
        Training data
    y : array-like of shape (n_samples,)
        Target labels (+1, -1)
    max_iter : int
        Maximum number of PSO iterations
    n_particles : int
        Number of particles in swarm
    w : float
        Inertia weight
    c1, c2 : float
        Cognitive and social parameters
        
    Returns:
    --------
    best_params : dict
        Best parameters found (rho, sigma, C)
    best_fitness : float
        Best accuracy achieved
    """
    # Parameter bounds
    bounds = {
        'rho': (0.01, 10.0),    # Wider range for rho
        'sigma': (0.001, 5.0),  # Wider range for sigma
        'C': (0.1, 10.0) 
    }
    
    # Initialize particles and velocities
    particles = []
    velocities = []
    for _ in range(n_particles):
        particle = {
            # Randomly initialize rho between its lower bound (0.1) and upper bound (5.0) using uniform distribution
            'rho': np.random.uniform(bounds['rho'][0], bounds['rho'][1]),
            # Randomly initialize sigma between its lower bound (0.01) and upper bound (2.0) using uniform distribution
            'sigma': np.random.uniform(bounds['sigma'][0], bounds['sigma'][1]),
            # Randomly initialize C between its lower bound (0.1) and upper bound (10.0) using uniform distribution
            'C': np.random.uniform(bounds['C'][0], bounds['C'][1])
        }
        velocity = {
            'rho': np.random.uniform(-0.5, 0.5),
            'sigma': np.random.uniform(-0.5, 0.5),
            'C': np.random.uniform(-0.5, 0.5)
        }
        particles.append(particle)
        velocities.append(velocity)
    
    # Initialize best positions
    personal_best = particles.copy()
    personal_best_fitness = [-np.inf] * n_particles
    global_best = particles[0].copy()
    global_best_fitness = -np.inf
    
    # PSO iterations
    for iteration in range(max_iter):
        for i in range(n_particles):
            # Calculate fitness using ADMM on validation set
            try:
                current_fitness = run_admm_and_get_accuracy(
                    X_train, y_train,
                    X_val, y_val,
                    particles[i]['C'],
                    particles[i]['sigma'],
                    particles[i]['rho'],
                    admm_max_iter=admm_max_iter
                )
                
                # Update personal best
                if current_fitness > personal_best_fitness[i]:
                    personal_best[i] = particles[i].copy()
                    personal_best_fitness[i] = current_fitness
                    
                    # Update global best
                    if current_fitness > global_best_fitness:
                        global_best = particles[i].copy()
                        global_best_fitness = current_fitness
                        
            except np.linalg.LinAlgError:
                # Handle numerical instability
                current_fitness = -np.inf
        
        # Update velocities and positions
        for i in range(n_particles):
            for param in ['rho', 'sigma', 'C']:
                # Update velocity
                velocities[i][param] = (
                    w * velocities[i][param] +
                    c1 * np.random.random() * (personal_best[i][param] - particles[i][param]) +
                    c2 * np.random.random() * (global_best[param] - particles[i][param])
                )
                
                # Update position
                particles[i][param] += velocities[i][param]
                
                # Apply bounds
                particles[i][param] = np.clip(
                    particles[i][param],
                    bounds[param][0],
                    bounds[param][1]
                )
        
        # Print progress

        print(f"Iteration {iteration + 1}/{max_iter}, Best fitness: {global_best_fitness:.4f}")
        print(f"Best parameters: rho={global_best['rho']:.4f}, "
                f"sigma={global_best['sigma']:.4f}, C={global_best['C']:.4f}")
    
    return global_best, global_best_fitness
    