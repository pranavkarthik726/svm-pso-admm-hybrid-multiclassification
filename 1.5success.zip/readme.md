changed fitness function in pso feature extraction required low accuracy
